package modelo;

public class Transacciones {
	private String transactionId;
	private String senderUserId;
	private String receiverUserId;
	private double cantidad;

	    // Getters y Setters
	    public String getTransactionId() {
	        return transactionId;
	    }

	    public void setTransactionId(String transactionId) {
	        this.transactionId = transactionId;
	    }

	    public String getSenderUserId() {
	        return senderUserId;
	    }

	    public void setSenderUserId(String senderUserId) {
	        this.senderUserId = senderUserId;
	    }

	    public String getReceiverUserId() {
	        return receiverUserId;
	    }

	    public void setReceiverUserId(String receiverUserId) {
	        this.receiverUserId = receiverUserId;
	    }

	    public double getCantidad() {
	        return cantidad;
	    }

	    public void setCantidad(double cantidad) {
	        this.cantidad = cantidad;
	    }

	}

