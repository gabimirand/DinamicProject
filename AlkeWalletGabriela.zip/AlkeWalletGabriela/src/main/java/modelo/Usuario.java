package modelo;

public class Usuario {

 private String userId;
 private String nombreUsuario;
 private String contrasena;

 // Getters y Setters
 public String getUserId() {
     return userId;
 }

 public void setUserId(String userId) {
     this.userId = userId;
 }

 public String getNombreUsuario() {
     return nombreUsuario;
 }

 public void setNombreUsuario(String nombreUsuario) {
     this.nombreUsuario = "usuario1";
 }

 public String getContrasena() {
     return contrasena;
 }

 public void setContrasena(String contrasena) {
     this.contrasena = "1234";
 }
}

