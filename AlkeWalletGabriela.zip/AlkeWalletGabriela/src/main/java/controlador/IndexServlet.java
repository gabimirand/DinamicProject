package controlador;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.CuentaBilletera;

@SuppressWarnings("serial")
public class IndexServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Simulación de cuentas (aquí se debería conectar a una base de datos)
        List<CuentaBilletera> cuenta = new ArrayList<>();
        cuenta.add(new CuentaBilletera("Gabriela", 12345, 10000));
        cuenta.add(new CuentaBilletera("Ian", 67890, 250000));

        request.setAttribute("cuentas", cuenta);
        request.getRequestDispatcher("WEB-INF/views/dashboard.jsp").forward(request, response);
    }
}